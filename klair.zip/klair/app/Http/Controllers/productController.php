<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class productController extends Controller
{
    //
    public function showUploadform(Request $request)
    {
    return view('uploadForm');
    }

}
