<html>
<head>
    <title>Laravel 6 Import Excel to database - W3Adda</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
</head>

<body>
    
<div class="container">
    <div class="card mt-4">
        <div class="card-header">
            Laravel 6 Import Excel to database - W3Adda
        </div>
            <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
        </div>
    <?php endif; ?>
   <?php if($message = Session::get('success')): ?>
   <div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>
           <strong><?php echo e($message); ?></strong>
   </div>
   <?php endif; ?>
        <div class="card-body">
            <form action="<?php echo e(url('import-excel')); ?>" method="POST" name="importform" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="import_file" class="form-control">
                <br>
                <button class="btn btn-success">Import File</button>
            </form>
        </div>
    </div>
    <div class="panel panel-default">
    <div class="panel-heading">
     <h3 class="panel-title">Customer Data</h3>
    </div>

    <div class="panel-body">
     <div class="table-responsive">
      <table class="table table-bordered table-striped">
       <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
               </tr>
       <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <td><?php echo e($c->date); ?></td>
        <td><?php echo e($c->category); ?></td>
        <td><?php echo e($c->lot_title); ?></td>
        <td><?php echo e($c->lot_location); ?></td>
        <td><?php echo e($c->lot_condition); ?></td>
        <td><?php echo e($c->pre_tax_amount); ?></td>
        <td><?php echo e($c->tax_name); ?></td>
        <td><?php echo e($c->tax_amount); ?></td>

       </tr>								

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
     </div>
    </div>
</div>
</div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\klair\resources\views/import_excel/index.blade.php ENDPATH**/ ?>